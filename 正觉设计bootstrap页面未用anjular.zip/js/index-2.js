var url = window.location.search; 
var loc = url.substring(url.lastIndexOf('=')+1, url.length); 
var OriginalHref = document.getElementById(loc).className; 
document.getElementById(loc).setAttribute("class", OriginalHref+" active"); 

